import React from 'react'

function Year() {
  return (
    <div>Year</div>
  )
}

export default Year